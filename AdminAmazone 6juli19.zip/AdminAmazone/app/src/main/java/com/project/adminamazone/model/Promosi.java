package com.project.adminamazone.model;

import com.google.firebase.database.IgnoreExtraProperties;

import java.io.Serializable;

public class Promosi implements Serializable{

    private String title;
    private String image;
    private String description;

    public Promosi(){

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return " "+title+"\n" +
                " "+image +"\n" +
                " "+description;
    }

    public Promosi(String ttle, String img, String desc){
        title = ttle;
        image = img;
        description = desc;
    }

}
